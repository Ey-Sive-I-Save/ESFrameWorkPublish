---
name: es-codex-session-bootstrap
description: Start, resume, fork, diagnose, and initialize Codex sessions for the ESFramework project. Use when the user says "打开新 Codex", "开启新对话", "恢复对话", "继续旧会话", "分叉会话", "初始化 Codex", "接手项目", or asks to launch Codex from the project root with the minimum authoritative ES context.
---

# Bootstrap ES Codex Sessions

Use the project-root launcher to cross the boundary between an existing conversation and a new interactive Codex process. Do not pretend that a prompt inside the current thread created a new conversation.

## Workflow

1. Run `scripts/Start-ESCodexSession.ps1 -Mode Validate -DryRun` before the first launch in an environment. Report missing CLI, project root, start files, or history paths.
2. Interpret “打开新 Codex”, “开启新对话”, or “初始化新会话” as `-Mode New`. Launch from the fixed repository root with the minimum initialization prompt.
3. Interpret “恢复对话” or “继续旧会话” as `-Mode Resume`. When an exact session ID is known, pass `-SessionId`; otherwise open the official Codex resume picker. Never choose a fuzzy search candidate automatically.
4. Interpret “分叉会话” as `-Mode Fork`. Prefer fork when the user wants the old transcript as context but does not want to continue mutating the original conversation.
5. When the user supplies only topic words, use `ES/AI协作历程（Codex）/Tools/Find-CodexSession.ps1` read-only. Show candidates and require identity confirmation before passing a session ID to the launcher.
6. In a newly initialized session, read only the start chain: AIWarnings `README`, `CurrentStatus`, and `RuleIndex`. Then load the matched P0 and domain rules for the actual task. Do not recursively read all AIWarnings.
7. Treat module audit state and AI collaboration history as optional recovery sources. Read them only when the requested task needs them. Never write or claim an old history archive without current user authorization.
8. Recheck Git branch, HEAD, staged/unstaged/untracked paths, relevant source, current rules, and evidence after resume. A transcript or checkpoint is navigation, not current truth.

## Launch commands

```powershell
# Validate without opening a terminal
& '.\.agents\skills\es-codex-session-bootstrap\scripts\Start-ESCodexSession.ps1' -Mode Validate -DryRun

# Open a new initialized Codex conversation
& '.\.agents\skills\es-codex-session-bootstrap\scripts\Start-ESCodexSession.ps1' -Mode New

# Open the official resume picker
& '.\.agents\skills\es-codex-session-bootstrap\scripts\Start-ESCodexSession.ps1' -Mode Resume

# Resume or fork an exact confirmed session
& '.\.agents\skills\es-codex-session-bootstrap\scripts\Start-ESCodexSession.ps1' -Mode Resume -SessionId '<uuid>'
& '.\.agents\skills\es-codex-session-bootstrap\scripts\Start-ESCodexSession.ps1' -Mode Fork -SessionId '<uuid>'
```

Read [references/session-bootstrap-contract.md](references/session-bootstrap-contract.md) before changing launch behavior or recovery authority.

## Required output

Report the selected mode, fixed project root, whether a visible process was launched, whether the session was selected exactly or through the official picker, initialization scope, and any recovery evidence that remains unconfirmed.

