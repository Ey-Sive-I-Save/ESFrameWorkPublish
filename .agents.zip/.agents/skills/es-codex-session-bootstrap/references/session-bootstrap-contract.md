# ES Codex Session Bootstrap Contract

## Capability boundary

- `codex` starts a new interactive terminal session.
- `codex resume` continues a saved interactive session by exact ID or through the official picker.
- `codex fork` creates a new conversation from a saved session transcript while preserving the original.
- A project Skill cannot create a new UI thread by prose alone. It must invoke a supported Codex surface or give the user the exact command.

## Fixed project root

Always launch with:

```text
F:\aaProject\ESFrameWorkPublish
```

The launcher also derives the same root from its installed project location and fails when the requested override resolves elsewhere.

## Initialization scope

The initial prompt may authorize only read-only project initialization:

1. Read AIWarnings `README.md`.
2. Read `当前状态（CurrentStatus）.md`.
3. Read `规则索引（RuleIndex）.md`.
4. Inspect branch, HEAD, and worktree status.
5. Wait for or execute the user's actual task under the matching rules.

It does not authorize source edits, Git operations, Unity execution, history maintenance, audit-state writes, publishing, or deletion.

## Recovery safety

- Prefer an exact session ID supplied by Codex or confirmed by the user.
- When only topic words are known, use `Find-CodexSession.ps1`; search scores rank candidates but never authorize resume or archive writes.
- Use the official picker when identity is not known. Do not silently choose `--last` in a multi-project environment.
- After resume or fork, refresh current repository facts. Old conversation context, archive files, and checkpoints may be stale.
- Never modify `%USERPROFILE%\.codex\history.jsonl` or session JSONL files.

