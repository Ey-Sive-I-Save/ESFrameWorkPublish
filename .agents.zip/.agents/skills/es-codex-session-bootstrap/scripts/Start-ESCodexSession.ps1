[CmdletBinding()]
param(
    [ValidateSet('Validate', 'New', 'Resume', 'Fork')]
    [string]$Mode = 'New',

    [string]$SessionId = '',

    [string]$ProjectPath = '',

    [switch]$AllSessions,

    [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
$OutputEncoding = [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)

function Get-QuotedPowerShellLiteral([string]$Value) {
    return "'" + $Value.Replace("'", "''") + "'"
}

$skillDirectory = Split-Path -Parent $PSScriptRoot
$skillsDirectory = Split-Path -Parent $skillDirectory
$agentsDirectory = Split-Path -Parent $skillsDirectory
$derivedProjectRoot = Split-Path -Parent $agentsDirectory
$fixedProjectRoot = 'F:\aaProject\ESFrameWorkPublish'
$installedProjectRoot = [System.IO.Path]::GetFullPath($derivedProjectRoot).TrimEnd('\')
if (-not $installedProjectRoot.Equals($fixedProjectRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Skill location does not match the fixed ESFramework root: $fixedProjectRoot"
}

if ([string]::IsNullOrWhiteSpace($ProjectPath)) {
    $resolvedProjectRoot = $fixedProjectRoot
}
else {
    $resolvedProjectRoot = [System.IO.Path]::GetFullPath((Resolve-Path -LiteralPath $ProjectPath).Path).TrimEnd('\')
    if (-not $resolvedProjectRoot.Equals($fixedProjectRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "ProjectPath must resolve to the fixed ESFramework root: $fixedProjectRoot"
    }
}

$requiredPatterns = @(
    'Assets/Plugins/ES/AIWarnings/00_*/README.md',
    'Assets/Plugins/ES/AIWarnings/00_*/*CurrentStatus*.md',
    'Assets/Plugins/ES/AIWarnings/00_*/*RuleIndex*.md',
    'ES/*Codex*/Tools/Find-CodexSession.ps1'
)

$missingPaths = @(
    $requiredPatterns | Where-Object {
        @((Get-ChildItem -Path (Join-Path $resolvedProjectRoot $_) -File -ErrorAction SilentlyContinue)).Count -ne 1
    }
)

$codexCommand = Get-Command codex -ErrorAction SilentlyContinue
if ($null -eq $codexCommand) {
    throw 'Codex CLI was not found on PATH.'
}
if ($missingPaths.Count -gt 0) {
    throw "Required bootstrap paths are missing:`n$($missingPaths -join "`n")"
}

$initialPrompt = @(
    'Initialize the ESFramework project session in read-only mode.',
    '1. Read the unique README.md under Assets/Plugins/ES/AIWarnings/00_*.',
    '2. Read the files matching *CurrentStatus*.md and *RuleIndex*.md in that directory.',
    '3. Inspect the current branch, HEAD, and worktree. Do not modify, stage, or commit.',
    '4. Load only the P0 and domain rules matched by the current user task. Do not recursively read all AIWarnings.',
    '5. Do not create, recover, or append AI collaboration history and do not write module audit state without current explicit user authorization.',
    'Report the loaded entry files, current Git state, and the task waiting to be executed.'
) -join "`n"

$codexArguments = [System.Collections.Generic.List[string]]::new()
switch ($Mode) {
    'Validate' {
        # Validation intentionally builds no interactive command.
    }
    'New' {
        $codexArguments.Add('-C')
        $codexArguments.Add($resolvedProjectRoot)
        $codexArguments.Add($initialPrompt.Trim())
    }
    'Resume' {
        $codexArguments.Add('resume')
        $codexArguments.Add('-C')
        $codexArguments.Add($resolvedProjectRoot)
        if ($AllSessions) { $codexArguments.Add('--all') }
        if (-not [string]::IsNullOrWhiteSpace($SessionId)) {
            $codexArguments.Add($SessionId.Trim())
            $codexArguments.Add($initialPrompt.Trim())
        }
    }
    'Fork' {
        $codexArguments.Add('fork')
        $codexArguments.Add('-C')
        $codexArguments.Add($resolvedProjectRoot)
        if ($AllSessions) { $codexArguments.Add('--all') }
        if (-not [string]::IsNullOrWhiteSpace($SessionId)) {
            $codexArguments.Add($SessionId.Trim())
            $codexArguments.Add($initialPrompt.Trim())
        }
    }
}

$result = [ordered]@{
    mode = $Mode
    projectRoot = $resolvedProjectRoot
    codexCli = $codexCommand.Source
    exactSession = -not [string]::IsNullOrWhiteSpace($SessionId)
    usesOfficialPicker = $Mode -in @('Resume', 'Fork') -and [string]::IsNullOrWhiteSpace($SessionId)
    requiredPathsValid = $true
    codexArguments = @($codexArguments)
    launched = $false
    dryRun = [bool]$DryRun
}

if ($Mode -eq 'Validate' -or $DryRun) {
    [pscustomobject]$result
    return
}

$invokeParts = @('&', (Get-QuotedPowerShellLiteral $codexCommand.Source))
$invokeParts += @($codexArguments | ForEach-Object { Get-QuotedPowerShellLiteral $_ })
$invokeCommand = $invokeParts -join ' '
$encodedCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($invokeCommand))

$null = Start-Process -FilePath 'powershell.exe' -ArgumentList @(
    '-NoExit',
    '-EncodedCommand',
    $encodedCommand
) -WorkingDirectory $resolvedProjectRoot

$result.launched = $true
[pscustomobject]$result
