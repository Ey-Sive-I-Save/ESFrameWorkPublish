using ES;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace ES {
    /*可装载完整运行时逻辑的对象，通常实现有 技能 高级Buff 飞行物*/ 
    public interface IRuntimeLogic 
    {
       

    }

}
