# 资源模式复核、Scope Registry 实现与 AIWarnings 更新

- 窗口档案ID：`ES-CODEX-20260804-052025`
- 建档时间：2026-08-04 05:20:25（Asia/Shanghai）
- 当前路径：`F:/aaProject/ESFrameWorkPublish/ES/AI协作历程（Codex）/2026-08-04_052025_资源模式复核_ScopeRegistry实现_AIWarnings更新.md`
- 状态：源码实现与规则更新已发生；Unity 运行验收未完成。
- 说明：本文件只记录当前对话窗口，不续写或认领其他窗口档案。

## 任务时间线

### T001：复核 LocalBuild 与 HotUpdate/Net 发布主链

- 用户要求：直接查源码判断发布、下载、缓存、Provider、Catalog、GameCore 与增量激活是否闭环。
- 实际动作：检查 `MODULE_ESRuntimeDataModule`、`ESRuntimeReleaseDownloader`、Release Bootstrap 与 Provider Transition 控制流。
- 结论：LocalBuild 与 HotUpdate/Net 的源码主链已闭环；Unity、IL2CPP 与真实网络证据不因此自动通过。

### T002：区分 EditorDirect 与 EditorSimulateBuild

- 用户要求：明确两种编辑器模式的真实区别。
- 纠正过程：早期曾把 EditorSimulateBuild 理解为读取本地 Bundle；用户冻结其目标为“正式发布元数据预检 + AssetDatabase 物理加载，不下载 Bundle”。
- 结论：EditorDirect 允许无发布物；EditorSimulateBuild 必须属于正式 RuntimeMap/Catalog。

### T003：实现 EditorSimulateBuild 第一版

- 实际修改：为 Direct Loader 增加可选 RuntimeMap 身份预检；Factory 将 EditorSimulateBuild 路由到 Direct Provider；Downloader 增加只读取发布元数据、不下载 Bundle/代码包的入口；Editor 临时会话接入本地或网络元数据来源。
- 验证：只完成源码与空白检查；Unity 编译、PlayMode、真实网络未验收。

### T004：确认四种资源模式的状态口径

- 结论：四种资源模式的源码主控制流和后端分流闭环；运行级验收未完成。
- 四模式：EditorDirect、EditorSimulateBuild、LocalBuild、HotUpdate/Net。

### T005：复核 ConfigKey 全模式主链

- 实际检查：Catalog 重建、AssetConfigKeyTable、RuntimeKey、GUID/LocalFileId、AssetTable Loader 和 Provider 入口。
- 结论：ConfigKey 到 Identity/Provider 的四模式主链存在；Key 未登记后的 Consumer/Library 激活与重新解析尚未形成统一公共门面。

### T006：冻结同步判断到异步加载标准

- 决策：热路径使用 `TryGetReady/TryGetOwned`；未命中只进入一次异步状态机。ConfigKey 只解析身份，生命周期必须落入 Owner、Scope、ResourcePlan、Resident 或 Temporary Lease。
- 禁止：新增无 Owner/Scope/Plan/Resident 语义的 `LoadAssetAsync(key)`。

### T007：复核 callback 完成保证与性能

- 结论：内置 AssetTable Loader 的正常终态会使非空 callback 至多一次且通常恰好一次；第三方 Loader 永不回调时接口没有强制终结保证。
- 性能结论：callback 冷路径可接受，捕获 lambda 不应进入每帧热路径；新版业务应优先同步判断和 UniTask 冷路径。

### T008：收口 Resident 语义

- 决策：Resident 只用于 GameCore、启动预热、全局基础资产和资源会话自身，不作为普通业务默认入口。
- 目标：普通业务使用流程 Scope、Owner、ResourcePlan 或 Temporary。

### T009：讨论 ESResourceContext 与 Scope 池化

- 用户要求：游戏流程开始创建可统一释放的域，并担心 Scope Dispose/池化风险。
- 结论：公开 Scope 外壳直接 `new`、单次生命周期、Dispose 后永久失效；现有内部 PooledState 可保留，不能复活外壳。
- 后续简化：用户否决复杂 Context/Handle 暴露，改为 `ESAssets + 枚举/StringKey` Registry。

### T010：冻结最简 Scope Registry API

- 决策：普通业务只使用 `CreateScope(key)`、`LoadAsync(refer,key)`、`ReleaseScope(key)`；真实 Scope、Generation 和内部防御不公开。
- ResourcePlan：继续由 Coordinator 私有管理 Scope，不接入 Registry。

### T011：增加父子级联生命周期

- 用户要求：一个枚举/StringKey Scope 可选绑定父 Scope，父释放时顺便释放子 Scope。
- 设计：单父级、子先父后、禁止自绑定和环、子可提前释放。

### T012：实现 Scope Registry 第一版

- 修改文件：`ESAssetScope.cs`、`ESAssetRefer.cs`。
- 实现：新增 `ESAssetDomain`、枚举/StringKey Registry、显式创建、加载、释放、父子级联；Provider Transition 清空 Registry。
- 默认行为：`ESAssets.LoadAsync(refer)` 改为已建立的 GameSession 域；未建立时失败，不再进入 Resident。
- 补充入口：`LoadResidentAsync`、`LoadTemporaryAsync`；`PreloadAsync` 明确进入 Resident。

### T013：性能收紧

- 实现：枚举 Key 使用值类型；Registry 只做字典查询；子集合懒创建；释放父级时才创建子级快照；没有 Update 轮询、LINQ 或反射。
- 边界：未取得 Unity Profiler 证据。

### T014：处理枚举与 StringKey 诊断同名

- 用户复核：枚举 `GameSession` 与字符串 `"GameSession"` 看起来同名但实际为不同节点。
- 实现：枚举诊断统一为保留命名空间 `@domain:*`；StringKey 禁止保留前缀和枚举同名，推荐业务前缀 `scene:*`、`ui:*`、`feature:*`。

### T015：TemporaryScope 可见性讨论与最终决定

- 中间动作：曾把 `ESAssetTemporaryScope` 与 `ESAssets.TemporaryScope` 降为内部入口。
- 用户纠正：允许高级用户直接取得并 Dispose 全局 TemporaryScope。
- 最终实现：恢复公开类型、公开属性和显式 Scope 重载；保留 `LoadTemporaryAsync` 作为推荐 Lease 门面。
- 语义：全局 Dispose 是全域清理，会使其他旧 Lease 一并失效；底层幂等与 generation 防串代继续成立。

### T016：确认 Owner 路径

- 结论：`ESAssets.LoadAsync(refer, owner)`、`refer.LoadAsync(owner)` 和 `TryGetOwned` 保留；OwnerTracker 管理独立 Scope，并在 Owner 销毁时释放。

### T017：CancellationToken 边界

- 结论：Token 非必填；`CancellationToken.None` 是无分配的商业级默认。确需提前结束等待时使用已有生命周期 Token，禁止每次加载无意义创建 CTS。

### T018：更新 AIWarnings

- 用户授权：更新 AIWarnings 和协作历程。
- 修改：README 强制结论、CurrentStatus、资源运行时 P0、ResourcePlan/Scope 商业验收矩阵。
- 状态口径：Scope Registry 第一版源码成立；Unity Test Runner、Provider Transition、父子释放、Domain Reload、Profiler、IL2CPP 与真实网络仍未验收。

### T019：验证结果边界

- `git diff --check`：目标源码与文档未发现空白错误，仅有 LF→CRLF 提示。
- `dotnet build ES_Stand.csproj`：被 Unity 尚未刷新生成工程中的 21 个旧 V1 路径 `CS2001` 阻断。
- 禁止结论：不得写 Unity 编译、PlayMode、Profiler、IL2CPP 或真实网络已通过。

## 当前源码状态摘要

1. 四种资源模式源码主链已形成，运行证据分层保留。
2. 默认无 Owner 加载已进入显式 GameSession Registry Scope，而非 Resident。
3. Registry 支持枚举/StringKey、父子级联和 Provider Transition 清理。
4. Owner、ResourcePlan 私有 Scope、Resident、Temporary 引用与 Lease 继续保持独立。
5. TemporaryScope 保持公开高级入口；普通短期任务推荐使用独立 Lease。

## 未完成项

- Unity 重新生成 IDE 工程并完成 Editor 编译。
- Scope Registry R1-R8 Unity Test Runner。
- 四模式 PlayMode 加载、失败、取消和快速重入。
- Provider Transition 与关闭 Domain Reload 重复进入。
- Profiler、IL2CPP、目标设备和真实网络发布。

