
using ES;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName ="TEST",menuName ="TEST1_2")]
public class Test1GlobalDara2 : ESEditorGlobalSo<Test1GlobalDara2>
{
    
}
