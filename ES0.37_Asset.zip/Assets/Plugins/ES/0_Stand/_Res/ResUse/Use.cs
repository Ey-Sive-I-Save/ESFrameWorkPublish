using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace ES
{
    public class Use : MonoBehaviour
    {
    
        void Start()
        {
            
        }

    
        void Update()
        {
            
        }
    }
}
