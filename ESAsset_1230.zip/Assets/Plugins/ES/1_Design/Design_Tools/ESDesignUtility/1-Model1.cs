using ES;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ES
{
    public static partial class ESDesignUtility
    {
        //只作为模板
        public class xxx
        {

        }
    }
}

