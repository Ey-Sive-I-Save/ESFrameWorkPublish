using UnityEngine;

namespace Gaskellgames
{
    /// <remarks>
    /// Code created by Gaskellgames: https://gaskellgames.com
    /// </remarks>

    [SelectionBase]
    [AddComponentMenu("Gaskellgames/GgCore/Selection Target")]
    public class SelectionTarget : MonoBehaviour
    {
        // blank
        
    } // class end
}
