
using ES;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName ="TEST",menuName ="TEST1")]
public class Test1GlobalDara : ESEditorGlobalSo<Test1GlobalDara>
{
    public string Title = "哈哈哈哈";
}
