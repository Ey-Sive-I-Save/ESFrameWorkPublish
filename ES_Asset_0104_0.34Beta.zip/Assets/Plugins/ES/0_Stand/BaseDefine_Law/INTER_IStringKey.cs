using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace ES
{
    public interface IString
    {
        public string GetSTR();
        public void SetSTR(string str);
    }
}
