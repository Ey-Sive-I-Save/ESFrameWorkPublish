﻿
using Sirenix.OdinInspector;
using UnityEngine;
 namespace ES{ 
     [ESCreatePath("常规SO新分组", "数据名SO")]
     public class SoNameSO : ESSO
     {
         
         }
     }

//ES已修正