using ES;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace ES {
    /// <summary>
    /// 自定义对拖动事件的支持嘻
    /// </summary>
    public class ESDragAttribute : Attribute
    {
          
    }
}
