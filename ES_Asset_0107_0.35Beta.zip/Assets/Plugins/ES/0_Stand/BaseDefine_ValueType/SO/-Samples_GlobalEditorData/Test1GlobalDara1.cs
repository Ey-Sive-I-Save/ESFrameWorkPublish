
using ES;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName ="TEST",menuName ="TEST1_1")]
public class Test1GlobalDara1 : ESEditorGlobalSo<Test1GlobalDara1>
{
    
}
