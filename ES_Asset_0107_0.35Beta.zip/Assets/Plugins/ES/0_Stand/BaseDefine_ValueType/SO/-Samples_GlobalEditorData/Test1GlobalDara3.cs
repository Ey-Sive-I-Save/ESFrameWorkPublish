
using ES;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName ="TEST",menuName ="TEST1_3")]
public class Test1GlobalDara3 : ESEditorGlobalSo<Test1GlobalDara3>
{
    
}
