using ES;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace ES {
    /// <summary>
    /// 掌管一些系统性质的内容
    /// </summary>
    public static class ESSystem 
    {
        public static bool IsQuitting = false;
    }
}
