using UnityEngine;

namespace Gaskellgames
{
    /// <remarks>
    /// Code created by Gaskellgames: https://gaskellgames.com
    /// </remarks>
    
    public class Sample_Property_SubTransform : MonoBehaviour
    {
        // ---------- SubTransform ----------

        [SerializeField]
        private SubTransform subTransform;

    } // class end
}