using ES;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace ES {
    public abstract class NodeRunnerSupport_Opeation<On,Operation,Contain> : NodeRunnerDynamicSO< Operation> where Contain:NodeContainerSO
    {
        
    }
}
